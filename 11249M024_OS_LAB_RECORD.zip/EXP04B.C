#include <stdio.h>
#include <pthread.h>
#include <semaphore.h>
#include <unistd.h>

#define N 5

#define THINKING 0
#define HUNGRY   1
#define EATING   2

#define LEFT  (phnum + N - 1) % N
#define RIGHT (phnum + 1) % N

int state[N];
int phil_num[N] = {0, 1, 2, 3, 4};

sem_t mutex;
sem_t S[N];

void test(int phnum)
{
    if (state[phnum] == HUNGRY &&
        state[LEFT] != EATING &&
        state[RIGHT] != EATING)
    {
        state[phnum] = EATING;

        printf("Philosopher %d takes forks %d and %d\n",
               phnum + 1, LEFT + 1, phnum + 1);

        printf("Philosopher %d is EATING\n", phnum + 1);

        sleep(1);

        sem_post(&S[phnum]);
    }
}

void take_fork(int phnum)
{
    sem_wait(&mutex);

    state[phnum] = HUNGRY;
    printf("Philosopher %d is HUNGRY\n", phnum + 1);

    test(phnum);

    sem_post(&mutex);

    sem_wait(&S[phnum]);
}

void put_fork(int phnum)
{
    sem_wait(&mutex);

    state[phnum] = THINKING;

    printf("Philosopher %d putting forks %d and %d down\n",
           phnum + 1, LEFT + 1, phnum + 1);

    printf("Philosopher %d is THINKING\n", phnum + 1);

    test(LEFT);
    test(RIGHT);

    sem_post(&mutex);
}

void* philosopher(void* num)
{
    int phnum = *(int*)num;

    while (1)
    {
        sleep(1);

        take_fork(phnum);

        sleep(1);

        put_fork(phnum);
    }
}

int main()
{
    int i;
    pthread_t thread_id[N];

    sem_init(&mutex, 0, 1);

    for (i = 0; i < N; i++)
        sem_init(&S[i], 0, 0);

    for (i = 0; i < N; i++)
    {
        pthread_create(&thread_id[i], NULL, philosopher, &phil_num[i]);
        printf("Philosopher %d is THINKING\n", i + 1);
    }

    for (i = 0; i < N; i++)
        pthread_join(thread_id[i], NULL);

    return 0;
}
